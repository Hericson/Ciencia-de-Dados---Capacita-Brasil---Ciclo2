import os
import pandas as pd
import optuna
from sklearn.metrics import mean_squared_error
from models.GD import GD
from util.processing import aumentoPolinomialDF

def carregar_dados():
    caminho_csv_noPCA = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'data', 'modifiedDataset', 'newDataset_NoPCA.csv')
    )
    df = pd.read_csv(caminho_csv_noPCA).drop(index=0).astype(float).reset_index(drop=True)
    return df

def objective(trial):
    df = carregar_dados()

    p = trial.suggest_int("p", 1, 4)
    alfa = trial.suggest_float("alfa", 0.001, 0.1, log=True)
    epocas = trial.suggest_int("epocas", 500, 3000, step=500)

    df_poly = aumentoPolinomialDF(df, p)
    model = GD(df_poly, alfa=alfa, epocas=epocas)

    try:
        model.fit()
        y_pred = model.predict(model.X_test)
        y_true = model.y_test
        return mean_squared_error(y_true, y_pred)
    except (FloatingPointError, ValueError):
        return float('inf')



def run_optimization(n_trials=50):
    study = optuna.create_study(direction="minimize")
    study.optimize(objective, n_trials=n_trials)
    return study.best_params

if __name__ == "__main__":
    best_params = run_optimization()
    print("Melhores hiperparâmetros encontrados:", best_params)