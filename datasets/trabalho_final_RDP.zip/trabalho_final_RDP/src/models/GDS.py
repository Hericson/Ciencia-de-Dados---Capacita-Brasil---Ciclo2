from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import pandas as pd
import numpy as np

class GDS:
    def __init__(self, df, alfa=0.01, epocas=100):
        self.df = df
        self.alfa = alfa
        self.epocas = epocas
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None
        self.W = None
        self.max = None
        self.min = None
        self.erros = []
        self.pesos = []
        self.previsoes = []

    def PrepararDados(self):
        X = self.df.iloc[:, :-1]
        y = self.df.iloc[:, -1]
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(X, y, test_size=0.2, random_state=42)

        self.max = self.X_train.max()
        self.min = self.X_train.min()
        
        
        self.X_train = self.normalizar(self.X_train)
        self.X_test = self.normalizar(self.X_test)

    def normalizar(self, Z_norm):
        return (Z_norm - self.min) / (self.max - self.min)

    def desnormalizar(self, Z_norm):
        return Z_norm * (self.max - self.min) + self.min

    def fit(self, parada=1e-6):
        self.PrepararDados()

        X = self.X_train.values
        y = self.y_train.values.reshape(-1, 1)

        X_bias = np.concatenate([np.ones((X.shape[0], 1)), X], axis=1)
        n_amostras, n_features = X_bias.shape

        self.W = np.zeros((n_features, 1))
        custo_anterior = np.inf

        for epoca in range(self.epocas):
            indices = np.arange(n_amostras)
            np.random.shuffle(indices)

            for i in indices:
                xi = X_bias[i, :].reshape(1, -1)
                yi = y[i]

                y_pred = np.dot(xi, self.W)
                erro = y_pred - yi

                gradiente = 2 * xi.T * erro
                gradiente = np.clip(gradiente, -1e3, 1e3)
                self.W -= self.alfa * gradiente

            y_pred_full = np.dot(X_bias, self.W)
            erro_epoca = np.mean((y_pred_full - y) ** 2)

            self.erros.append(erro_epoca)
            self.pesos.append(self.W.copy())
            self.previsoes.append(y_pred_full)

            if abs(custo_anterior - erro_epoca) < parada:
                break

            custo_anterior = erro_epoca

        y_train_pred = self.predict(self.X_train.values)
        y_test_pred = self.predict(self.X_test.values)

        rmse_train = float(self.calcularRMSE(y_train_pred, self.y_train))
        rmse_test = float(self.calcularRMSE(y_test_pred, self.y_test))

        return "RMSE Treino: " + str(rmse_train), "RMSE Teste: " + str(rmse_test)

    def predict(self, X):
        X_bias = np.concatenate([np.ones((X.shape[0], 1)), X], axis=1)
        return np.dot(X_bias, self.W).flatten()

    def calcularRMSE(self, y_pred, y_true):
        return np.sqrt(mean_squared_error(y_true, y_pred))
