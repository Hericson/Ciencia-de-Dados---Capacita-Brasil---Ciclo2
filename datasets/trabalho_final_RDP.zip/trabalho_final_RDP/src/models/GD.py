from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import pandas as pd
import numpy as np

class GD:
    def __init__(self, df, alfa=0.01, epocas=1000):
        self.df = df
        self.alfa = alfa
        self.epocas = epocas
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None
        self.W = None
        self.max = None
        self.min = None
        self.erros = []
        self.pesos = []
        self.previsoes = []
        self.historico_rmse = []


    def PrepararDados(self):
        X = self.df.iloc[:, :-1]
        y = self.df.iloc[:, -1]
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        
        self.max = self.X_train.max()
        self.min = self.X_train.min()

        
        self.X_train = self.normalizar(self.X_train)
        self.X_test = self.normalizar(self.X_test)

    def normalizar(self, Z_norm):
        return (Z_norm - self.min) / (self.max - self.min)

    def desnormalizar(self, Z_norm):
        return Z_norm * (self.max - self.min) + self.min

    def fit(self, parada=1e-6):
        self.PrepararDados()

        X = self.X_train.values
        y = self.y_train.values.reshape(-1, 1)

        X_bias = np.concatenate([np.ones((X.shape[0], 1)), X], axis=1)

        self.W = np.zeros((X_bias.shape[1], 1))

        custo = np.inf
        for i in range(self.epocas):
            y_pred = np.dot(X_bias, self.W)
            erro = y_pred - y
            custo_atual = np.mean(erro ** 2)

            rmse_atual = np.sqrt(custo_atual)
            self.historico_rmse.append(rmse_atual)


            self.previsoes.append(y_pred)
            self.erros.append(custo_atual)
            self.pesos.append(self.W.copy())

            if abs(custo - custo_atual) < parada:
                break

            gradiente = 2 * np.dot(X_bias.T, erro) / X_bias.shape[0]
            self.W -= self.alfa * gradiente
            custo = custo_atual

        y_train_pred = self.predict(self.X_train.values)
        y_test_pred = self.predict(self.X_test.values)

        rmse_train = float(self.calcularRMSE(y_train_pred, self.y_train))
        rmse_test = float(self.calcularRMSE(y_test_pred, self.y_test))

        return "RMSE Treino: " + str(rmse_train), "RMSE Teste: " + str(rmse_test)

    def predict(self, X):
        X_bias = np.concatenate([np.ones((X.shape[0], 1)), X], axis=1)
        return np.dot(X_bias, self.W).flatten()

    def calcularRMSE(self, y_pred, y_true):
        return np.sqrt(mean_squared_error(y_true, y_pred))
