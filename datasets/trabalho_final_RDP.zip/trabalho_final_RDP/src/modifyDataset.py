from pathlib import Path
import pandas as pd
import numpy as np
import re

def dfToXY(df):
  x = df.drop(columns=df.columns[-1]).values.tolist()
  y = df[df.columns[-1]].tolist()
  x = np.array(x)
  y = np.array(y)
  return x, y

def Matriz_covariancia(X,x_media):
  n_features=X.shape[1]
  cov=np.zeros((n_features,n_features))

  for x in X:
    diff= (x-x_media).reshape(-1,1)
    cov+=np.dot(diff,diff.T)
  cov=cov/(X.shape[0]-1)
  return cov

def PCA(x,n_most_important_columns=2):
  x_medias=np.mean(x,axis=0)
  x_center=x-x_medias
  covariancia=Matriz_covariancia(x_center,0)
  autovalores, autovetores = np.linalg.eig(covariancia)
  autovalores_decres_idx=np.argsort(autovalores)[::-1]
  autovalores=autovalores[autovalores_decres_idx]
  autovetores=autovetores[:,autovalores_decres_idx]

  main_columns= autovetores[:,:n_most_important_columns]
  x_pca=np.dot(x_center,main_columns)

  var_total=[]
  for n in range(1,x.shape[1]+1):
     sum_used=np.sum(autovalores[:n])
     var_total.append(sum_used/np.sum(autovalores))
  return x_pca, var_total

def calcular_media_hit_dice(hit_dice):

    if pd.isna(hit_dice):
        return 0
    
    match = re.match(r'(\d+)d(\d+)([+-]\d+)?', hit_dice)
    if not match:
        return 0
    
    quantidade = int(match.group(1))
    faces = int(match.group(2))
    bonus = int(match.group(3)) if match.group(3) else 0
    
    media_dados = quantidade * (1 + faces) / 2
    total = media_dados + bonus
    return total

path = Path('data/originalDataset/monsters.csv')


df = pd.read_csv(path)

remove_columns = [
    "slug", "desc", "name", "type", "subtype", "group", "alignment", "armor_desc",
    "senses", "languages", "challenge_rating", "actions", "legendary_desc",
    "page_no", "environments", "img_main", "document__slug", "document__title",
    "document__license_url", "document__url", "speed.hover", "speed.notes",
    "speed.lightwalking", "speed.bur.", "special_abilities", "damage_vulnerabilities", "hit_dice","spell_list"
]

df = df.drop(remove_columns, axis=1)

# Onde temos NaN, colocamos 0
df = df.fillna(0)

# Movendo coluna CR(nosso y) para o fim do DF
y = df['cr']
df = df.drop(columns=['cr'])
df['cr'] = y

# Transformando legendary actions em true ou false
df['legendary_actions'] = df['legendary_actions'].apply(lambda x: 0 if (x == 0 or pd.isna(x) or str(x).strip() == '') else 1)

df = df.rename(columns={'spell_list':'spellcaster'})


# Cada tamanho ser um numero 0,1.....
# Ordem crescente de tamanhos
size_order = ['Tiny', 'Small', 'Medium', 'Large', 'Huge', 'Gargantuan', 'Titanic']
size_map = {size: idx for idx, size in enumerate(size_order)}

df['size'] = df['size'].map(size_map)


# Alterando reactions para 0 ou 1
df['reactions'] = df['reactions'].apply(lambda x: 0 if (x == 0 or pd.isna(x) or str(x).strip() == '') else 1)


# Quantas imunidades a condições o monstro tem
df['condition_immunities'] = df['condition_immunities'].apply(
    lambda x: 0 if pd.isna(x) or str(x).strip() == '' else len(str(x).split(','))
)

# Quantas resistencias o monstro tem
df['damage_resistances'] = df['damage_resistances'].apply(
    lambda x: 0 if pd.isna(x) or str(x).strip() == '' else len(str(x).split(','))
)

# Quantas imunidades a dano o monstro tem
df['damage_immunities'] = df['damage_immunities'].apply(
    lambda x: 0 if pd.isna(x) or str(x).strip() == '' else len(str(x).split(','))
)

#Salvando dataframe com PCA aplicado.
'''X,y=dfToXY(df)
x_pca,var_total=PCA(X,8)

y = y.reshape(-1, 1)
dados_completos = np.hstack((x_pca, y))
np.savetxt('data/modifiedDataset/newDataset.csv', dados_completos, delimiter=',', fmt='%f')'''

df = df.apply(pd.to_numeric, errors='coerce').fillna(0)

#Salvando dataframe sem PCA aplicado
df.to_csv('data/modifiedDataset/newDataset_NoPCA.csv', index=False)