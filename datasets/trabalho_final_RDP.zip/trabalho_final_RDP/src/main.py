from models.GD import GD
from models.GDS import GDS
from models.OLS import OLS
from util.processing import aumentoPolinomialDF, plot_rmse
from optimize_gd import run_optimization
import time
import os
import pandas as pd
import shap
import matplotlib.pyplot as plt

def plot_shap(model, nome_modelo="modelo", salvar_em=None):
    explainer = shap.Explainer(model.predict, masker=model.X_train)
    shap_values = explainer(model.X_test)

    shap.summary_plot(shap_values.values, model.X_test, feature_names=model.X_test.columns, show=False)
    if salvar_em:
        plt.savefig(f"{salvar_em}/{nome_modelo}_summary.png", bbox_inches='tight')
    plt.close()

    shap.plots.bar(shap_values, max_display=10, show=False)
    if salvar_em:
        plt.savefig(f"{salvar_em}/{nome_modelo}_bar.png", bbox_inches='tight')
    plt.close()

    for i in [0, 250, 486]:
        shap.plots.waterfall(shap_values[i], max_display=10, show=False)
        if salvar_em:
            plt.savefig(f"{salvar_em}/{nome_modelo}_waterfall_{i}.png", bbox_inches='tight')
        plt.close()


caminho_csv_noPCA = os.path.abspath(
    os.path.join(os.path.dirname(__file__), '..', 'data', 'modifiedDataset', 'newDataset_NoPCA.csv')
)
caminho_csv = os.path.abspath(
    os.path.join(os.path.dirname(__file__), '..', 'data', 'modifiedDataset', 'newDataset.csv')
)

df_PCA = pd.read_csv(caminho_csv)
df_NoPCA = pd.read_csv(caminho_csv_noPCA).drop(index=0).astype(float).reset_index(drop=True)

if __name__ == "__main__":
    print("Iniciando otimização dos hiperparâmetros com Optuna...")
    best_params = run_optimization(n_trials=50)
    print("Melhores hiperparâmetros encontrados:", best_params)

    p = best_params["p"]
    alfa = best_params["alfa"]
    epocas = best_params["epocas"]

    print(f"Usando p={p}, alfa={alfa:.6f}, epocas={epocas} para o treinamento.")

    df_PCA = aumentoPolinomialDF(df_PCA, p)
    df_NoPCA = aumentoPolinomialDF(df_NoPCA, p)

    GD_PCA = GD(df_PCA, alfa=alfa, epocas=epocas)
    GD_NoPCA = GD(df_NoPCA, alfa=alfa, epocas=epocas)
    GDS_PCA = GDS(df_PCA, alfa=alfa, epocas=int(epocas / 10))
    GDS_NoPCA = GDS(df_NoPCA, alfa=alfa, epocas=int(epocas / 10))
    OLS_PCA = OLS(df_PCA)
    OLS_NoPCA = OLS(df_NoPCA)

    pasta_graficos = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'static', 'graficos')
    )
    pasta_shap = os.path.abspath(
        os.path.join(pasta_graficos, 'shap')
    )
    os.makedirs(pasta_graficos, exist_ok=True)
    os.makedirs(pasta_shap, exist_ok=True)

    for nome, modelo in [
        ("GD com PCA", GD_PCA),
        ("GD sem PCA", GD_NoPCA),
        ("GDS com PCA", GDS_PCA),
        ("GDS sem PCA", GDS_NoPCA),
        ("OLS com PCA", OLS_PCA),
        ("OLS sem PCA", OLS_NoPCA)
    ]:
        print(nome)
        inicio = time.time()
        print(modelo.fit())
        fim = time.time()
        print(f"Demorou {fim - inicio:.20f} segundos para executar\n")

        if isinstance(modelo, GD):
            plot_rmse(modelo, nome)
            caminho_rmse = os.path.join(pasta_graficos, nome.replace(" ", "_") + "_rmse.png")
            plt.savefig(caminho_rmse, bbox_inches='tight')
            plt.close()
            print(f"Curva RMSE salva em: {caminho_rmse}")

        if "sem PCA" in nome:
            plot_shap(modelo, nome_modelo=nome.replace(" ", "_"), salvar_em=pasta_shap)
            print(f"Gráficos SHAP salvos para {nome}")
