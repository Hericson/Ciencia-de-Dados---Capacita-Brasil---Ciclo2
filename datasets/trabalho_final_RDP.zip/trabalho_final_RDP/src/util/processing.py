import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def dfToXY(df):
    """
    Separa o DataFrame em X (features), y (target) e nomes das colunas.
    """
    nome_colunas = df.columns.tolist()
    x = df.drop(columns=df.columns[-1]).values.tolist()
    y = df[df.columns[-1]].tolist()
    x = np.array(x)
    y = np.array(y)
    return x, y, nome_colunas

def AumentoPolinomial(x, poli):
    """
    Aumenta o grau polinomial das features de 1 a `poli`.
    """
    if poli == 1:
        return x

    if x.ndim == 1:
        x_final = x.reshape(-1, 1)
    else:
        x_final = x.copy()

    num_colunas = x_final.shape[1]

    for p in range(2, poli + 1):
        for col_index in range(num_colunas):
            coluna = x_final[:, col_index] ** p
            coluna = coluna.reshape(-1, 1)
            x_final = np.concatenate([x_final, coluna], axis=1)

    return x_final

def aumentoPolinomialDF(df, P):
    """
    Aplica aumento polinomial ao DataFrame, incluindo o target (última coluna).
    Retorna um novo DataFrame com os novos nomes de colunas.
    """
    X, y, nome_colunas = dfToXY(df)
    X = AumentoPolinomial(X, P)
    y = y.reshape(-1, 1)
    dados_completos = np.hstack((X, y))
    nome_colunas = nome_colunas[:-1]

    nova_lista_colunas = []
    for grau in range(1, P + 1):
        for nome in nome_colunas:
            if grau == 1:
                nova_lista_colunas.append(f"{nome}")
            else:
                nova_lista_colunas.append(f"{nome}^{grau}")

    nova_lista_colunas.append("CR")
    return pd.DataFrame(dados_completos, columns=nova_lista_colunas)

def plot_rmse(model, nome_modelo):
    if hasattr(model, 'historico_rmse'):
        plt.figure(figsize=(8, 4))
        plt.plot(model.historico_rmse, label='RMSE', color='blue')
        plt.title(f'Evolução do RMSE - {nome_modelo}')
        plt.xlabel('Épocas')
        plt.ylabel('RMSE')
        plt.grid(True)
        plt.legend()
        plt.tight_layout()
        plt.show()
    else:
        print(f"O modelo {nome_modelo} não possui histórico de RMSE.")
